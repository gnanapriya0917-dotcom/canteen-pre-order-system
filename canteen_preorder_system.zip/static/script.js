function showToast(message) {
    const toast = document.getElementById("toast");
    if (!toast) return;

    toast.textContent = message;
    toast.classList.add("show");

    setTimeout(() => {
        toast.classList.remove("show");
    }, 2200);
}

document.addEventListener("DOMContentLoaded", () => {
    const buttons = document.querySelectorAll(".add-btn");

    buttons.forEach(button => {
        button.addEventListener("click", async () => {
            const id = button.dataset.id;

            try {
                const response = await fetch(`/add_to_cart/${id}`, {
                    method: "POST"
                });

                const data = await response.json();

                if (data.success) {
                    showToast(data.message);

                    const count = document.getElementById("cartCount");
                    if (count) {
                        count.textContent = `(${data.cart_count})`;
                    }
                } else {
                    showToast(data.message || "Could not add item");
                }
            } catch (error) {
                showToast("Something went wrong.");
            }
        });
    });
});
