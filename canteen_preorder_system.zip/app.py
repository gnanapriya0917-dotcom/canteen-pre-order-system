from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
import random
from datetime import datetime

app = Flask(__name__)
app.secret_key = "canteen_secret_key"
DATABASE = "canteen.db"


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def create_tables():
    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS menu (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            available INTEGER DEFAULT 1
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_number TEXT UNIQUE,
            student_name TEXT NOT NULL,
            pickup_time TEXT NOT NULL,
            total REAL NOT NULL,
            status TEXT DEFAULT 'Placed',
            order_date TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            item_name TEXT NOT NULL,
            price REAL NOT NULL,
            quantity INTEGER NOT NULL
        )
    """)

    count = conn.execute("SELECT COUNT(*) FROM menu").fetchone()[0]

    if count == 0:
        sample_items = [
            ("Dosa", 40, 1),
            ("Idly", 30, 1),
            ("Samosa", 20, 1),
            ("Tea", 15, 1),
            ("Coffee", 20, 1),
            ("Veg Meals", 80, 1),
        ]
        conn.executemany(
            "INSERT INTO menu (name, price, available) VALUES (?, ?, ?)",
            sample_items
        )

    conn.commit()
    conn.close()


@app.route("/")
def index():
    conn = get_db()
    menu = conn.execute(
        "SELECT * FROM menu WHERE available = 1 ORDER BY name"
    ).fetchall()
    conn.close()
    return render_template("index.html", menu=menu)


@app.route("/cart")
def cart():
    cart_items = session.get("cart", [])
    total = sum(item["price"] * item["quantity"] for item in cart_items)
    return render_template("cart.html", cart=cart_items, total=total)


@app.route("/add_to_cart/<int:item_id>", methods=["POST"])
def add_to_cart(item_id):
    conn = get_db()
    item = conn.execute(
        "SELECT * FROM menu WHERE id = ? AND available = 1",
        (item_id,)
    ).fetchone()
    conn.close()

    if not item:
        return jsonify({"success": False, "message": "Item unavailable"}), 404

    cart = session.get("cart", [])
    found = False

    for cart_item in cart:
        if cart_item["id"] == item["id"]:
            cart_item["quantity"] += 1
            found = True
            break

    if not found:
        cart.append({
            "id": item["id"],
            "name": item["name"],
            "price": item["price"],
            "quantity": 1
        })

    session["cart"] = cart
    session.modified = True

    return jsonify({
        "success": True,
        "message": f"{item['name']} added to cart",
        "cart_count": sum(x["quantity"] for x in cart)
    })


@app.route("/remove/<int:item_id>")
def remove(item_id):
    cart = session.get("cart", [])
    cart = [item for item in cart if item["id"] != item_id]
    session["cart"] = cart
    return redirect(url_for("cart"))


@app.route("/update_cart", methods=["POST"])
def update_cart():
    cart = session.get("cart", [])

    for item in cart:
        value = request.form.get(f"quantity_{item['id']}", "1")
        try:
            quantity = max(1, int(value))
        except ValueError:
            quantity = 1
        item["quantity"] = quantity

    session["cart"] = cart
    return redirect(url_for("cart"))


@app.route("/place_order", methods=["POST"])
def place_order():
    cart = session.get("cart", [])

    if not cart:
        return redirect(url_for("cart"))

    student_name = request.form.get("student_name", "").strip()
    pickup_time = request.form.get("pickup_time", "").strip()

    if not student_name or not pickup_time:
        return "Student name and pickup time are required.", 400

    conn = get_db()
    today = datetime.now().strftime("%Y-%m-%d")

    slot_count = conn.execute(
        """
        SELECT COUNT(*) FROM orders
        WHERE pickup_time = ? AND order_date = ?
        """,
        (pickup_time, today)
    ).fetchone()[0]

    if slot_count >= 10:
        conn.close()
        return render_template(
            "message.html",
            title="Pickup Slot Full",
            message="This pickup slot is full. Please go back and choose another slot."
        )

    total = sum(item["price"] * item["quantity"] for item in cart)

    while True:
        order_number = "ACT-" + str(random.randint(10000, 99999))
        exists = conn.execute(
            "SELECT id FROM orders WHERE order_number = ?",
            (order_number,)
        ).fetchone()
        if not exists:
            break

    cursor = conn.execute(
        """
        INSERT INTO orders
        (order_number, student_name, pickup_time, total, status, order_date)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (order_number, student_name, pickup_time, total, "Placed", today)
    )

    order_id = cursor.lastrowid

    for item in cart:
        conn.execute(
            """
            INSERT INTO order_items
            (order_id, item_name, price, quantity)
            VALUES (?, ?, ?, ?)
            """,
            (order_id, item["name"], item["price"], item["quantity"])
        )

    conn.commit()
    conn.close()
    session["cart"] = []

    return render_template(
        "order.html",
        order_number=order_number,
        pickup_time=pickup_time,
        total=total
    )


@app.route("/track")
def track():
    order_number = request.args.get("order_number", "").strip()

    if not order_number:
        return render_template("track.html", order=None)

    conn = get_db()
    order = conn.execute(
        "SELECT * FROM orders WHERE order_number = ?",
        (order_number,)
    ).fetchone()
    conn.close()

    return render_template("track.html", order=order)


# ---------------- STAFF ----------------

@app.route("/staff")
def staff():
    conn = get_db()

    menu = conn.execute(
        "SELECT * FROM menu ORDER BY name"
    ).fetchall()

    orders = conn.execute(
        "SELECT * FROM orders ORDER BY id DESC"
    ).fetchall()

    today = datetime.now().strftime("%Y-%m-%d")

    summary = conn.execute(
        """
        SELECT item_name, SUM(quantity) AS total_quantity
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        WHERE o.order_date = ?
        GROUP BY item_name
        ORDER BY total_quantity DESC
        """,
        (today,)
    ).fetchall()

    today_orders = conn.execute(
        "SELECT COUNT(*) FROM orders WHERE order_date = ?",
        (today,)
    ).fetchone()[0]

    today_sales = conn.execute(
        "SELECT COALESCE(SUM(total), 0) FROM orders WHERE order_date = ?",
        (today,)
    ).fetchone()[0]

    conn.close()

    return render_template(
        "staff.html",
        menu=menu,
        orders=orders,
        summary=summary,
        today_orders=today_orders,
        today_sales=today_sales
    )


@app.route("/staff/add", methods=["POST"])
def add_menu():
    name = request.form.get("name", "").strip()
    price = request.form.get("price", "0")

    try:
        price = float(price)
    except ValueError:
        return "Invalid price.", 400

    if not name or price < 0:
        return "Invalid menu item.", 400

    conn = get_db()
    conn.execute(
        "INSERT INTO menu (name, price, available) VALUES (?, ?, 1)",
        (name, price)
    )
    conn.commit()
    conn.close()

    return redirect(url_for("staff"))


@app.route("/staff/update/<int:item_id>", methods=["POST"])
def update_menu(item_id):
    name = request.form.get("name", "").strip()
    price = request.form.get("price", "0")

    try:
        price = float(price)
    except ValueError:
        return "Invalid price.", 400

    conn = get_db()
    conn.execute(
        "UPDATE menu SET name = ?, price = ? WHERE id = ?",
        (name, price, item_id)
    )
    conn.commit()
    conn.close()

    return redirect(url_for("staff"))


@app.route("/staff/toggle/<int:item_id>")
def toggle_menu(item_id):
    conn = get_db()
    conn.execute(
        """
        UPDATE menu
        SET available = CASE WHEN available = 1 THEN 0 ELSE 1 END
        WHERE id = ?
        """,
        (item_id,)
    )
    conn.commit()
    conn.close()

    return redirect(url_for("staff"))


@app.route("/staff/status/<int:order_id>/<status>")
def update_status(order_id, status):
    allowed_status = ["Placed", "Preparing", "Ready", "Collected"]

    if status not in allowed_status:
        return "Invalid status.", 400

    conn = get_db()
    conn.execute(
        "UPDATE orders SET status = ? WHERE id = ?",
        (status, order_id)
    )
    conn.commit()
    conn.close()

    return redirect(url_for("staff"))


if __name__ == "__main__":
    create_tables()
    app.run(debug=True)
