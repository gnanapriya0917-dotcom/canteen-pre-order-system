# Smart Canteen Pre-Order System

A beginner-friendly Flask + SQLite web application for the Audisankara College of Engineering & Technology canteen.

## Features

- Daily menu display
- Food price and availability
- Add to cart
- Update/remove cart items
- Pickup time selection
- Maximum 10 orders per pickup slot
- Unique order number
- Order status:
  - Placed
  - Preparing
  - Ready
  - Collected
- Student order tracking
- Staff dashboard
- Add/update/disable menu items
- Daily order count and sales
- Daily food demand summary

## Requirements

- Python 3.10 or newer
- VS Code recommended

## Installation

Open a terminal in this project folder:

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

Then:

```bash
pip install -r requirements.txt
```

Run:

```bash
python app.py
```

Open in your browser:

Student:
http://127.0.0.1:5000/

Staff:
http://127.0.0.1:5000/staff

## Database

The SQLite database `canteen.db` is created automatically the first time the application runs.

## Important

This is a project/demo version. For production use, add authentication, payment security, CSRF protection, role-based access, proper validation and deployment configuration.
